package com.codeoftheweb.salvo.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.Collection;
import java.util.List;

@Entity
public class Ship {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
    @GenericGenerator(name = "native", strategy = "native")
    private long id;


    private TypeShip typeShip;


    @ManyToOne(fetch=FetchType.EAGER)
    @JoinColumn(name="gameplayer_id")
    @JsonIgnore
    private GamePlayer gamePlayer;

    @ElementCollection
    private List<String> location;

    public Ship(){};

    public Ship(TypeShip typeShip,GamePlayer gamePlayer,List<String> locations){
        this.typeShip=typeShip;
        this.gamePlayer=gamePlayer;
        this.location=locations;
    }

    public void addLocation(String location){
        this.location.add(location);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public TypeShip getTypeShip() {
        return typeShip;
    }

    public void setTypeShip(TypeShip typeShip) {
        this.typeShip = typeShip;
    }

    public GamePlayer getGamePlayer() {
        return gamePlayer;
    }

    public void setGamePlayer(GamePlayer gamePlayer) {
        this.gamePlayer = gamePlayer;
    }

    public Collection<String> getLocations() {
        return location;
    }

    public void setLocations(List<String> location) {
        this.location = location;
    }
}


