package com.codeoftheweb.salvo.controller;


import com.codeoftheweb.salvo.model.Game;
import com.codeoftheweb.salvo.model.GamePlayer;
import com.codeoftheweb.salvo.model.Player;
import com.codeoftheweb.salvo.model.Ship;
import com.codeoftheweb.salvo.repository.GamePlayerRepository;
import com.codeoftheweb.salvo.repository.GameRepository;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.xml.bind.annotation.adapters.CollapsedStringAdapter;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class SalvoController {

    @Autowired
    GameRepository gameRepository;

    @Autowired
    GamePlayerRepository gamePlayerRepository;

    @RequestMapping("/games")
    public List<Object> getListGames(){
        List<Game> games = gameRepository.findAll();
        return games.stream().map(this:: makeGamesDTO).collect(Collectors.toList());
    }

    @RequestMapping("/game_view/{id}")
    @JsonPropertyOrder({"id","created","GamePlayers","Ships"})
    public Map<String, Object> getGame(@PathVariable("id") Long id) {
        GamePlayer gamePlayer=gamePlayerRepository.getOne(id);
        Game game = gamePlayer.getGame();
        return this.makeGameswithShip(game);
    }


    private Map<String,Object> makeGamesDTO(Game game){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        Map map=new HashMap<String,Object>();
        Set<GamePlayer> gamePlayers= game.getGamePlayers();
        map.put("GamePlayers", gamePlayers.stream().map(this::makeGamesPlayerDTO));
        map.put("created",game.getCreationDate().format(formatter));
        map.put("id",game.getId());
        return  map;
    }

    private Map<String,Object> makeGamesPlayerDTO(GamePlayer gamePlayer){
        Map dto = new HashMap<String, Object>();
        dto.put("player", makePlayerDTO(gamePlayer.getPlayer()));
        dto.put("id", gamePlayer.getId());
        return dto;
    }

    private Map<String,Object> makePlayerDTO(Player player){
            Map dto = new HashMap<String, Object>();
            dto.put("email", player.getUserName());
            dto.put("id", player.getId());
            return dto;
    }

    private Map<String,Object> makeShipDTO(Ship ship){
        Map dto= new HashMap<String,Object>();
        dto.put("Type",ship.getTypeShip());
        dto.put("Location",ship.getLocations().stream().collect(Collectors.toList()));
        return dto;
    }

    private Map<String,Object> makeGameswithShip(Game game){
        Set<Ship> ships = new HashSet<Ship>();
        Map dto=this.makeGamesDTO(game);
        Set<GamePlayer> gamePlayers= game.getGamePlayers();
        gamePlayers.stream().forEach((gamePlayer)->{ships.addAll(gamePlayer.getShips());});
        dto.put("Ships", ships.stream().map(this::makeShipDTO).collect(Collectors.toList()));
        return dto;
    }


}
