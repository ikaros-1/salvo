$(function(){
    var id_gameplayer = $.urlParam("gp");
    maketable();
    if(id_gameplayer !=null){
        loadJsonShips(id_gameplayer);
    }
    else
    alert("Debe pedir un id desde la url");
})



/*function loadJson() {
    $.get("/api/games")
    .done(function(games) {
        games.map(function(game){
            if(game.GamePlayers.length <1 )
                $("#Lista").append("<li>"+game.id+" - "+game.created+" ");
            else{
                $("#Lista").append("<li>"+game.id+" - "+game.created+" ");
                game.GamePlayers.map(function(gameplayer){
                    $("#Lista").append(gameplayer.player.email+" ");
                })
                $("#Lista").append("</li>");
            }
        })
    })
    .fail(function( jqXHR, textStatus ) {
      alert("fallo")
    });
  }*/

  function loadJsonShips(id){
       $.get("/api/game_view/"+id,function(){
            alert("Cargo")
       })
      .done(function(games) {
            games.Ships.map(function(ship){
                ship.Location.map(function(loc){
                    console.log(loc)
                    $("#"+loc).append("<submarine1><submarine1/>")
                })
            })
            var you=games.GamePlayers.filter(gameplayer =>{return gameplayer.id==id}).shift();
            var oponent =games.GamePlayers.filter(gameplayer =>{return gameplayer.id!=id}).shift();
            /*games.GamePlayers.map(function(gameplayer){
                if(gameplayer.player.id==id_Player){
                    $("#players").append(gameplayer.player.email+"(you) vs");
                }
                else{
                    oponent=gameplayer.player.email;
                }
            })
            $("#oponent").append(oponent);*/
            $("#players").append(you.player.email+"(You) vs "+oponent.player.email)
      })
      .fail(function( jqXHR, textStatus ) {
        alert("fallo")
      });
  }

  $.urlParam = function(name){
               var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
               if (results==null) {
                  return null;
               }
               return decodeURI(results[1]) || 0;
           }


   function maketable(){
        for(var y="A";y!="K";y=String.fromCharCode(y.charCodeAt(0)+1)){
            $("#tbody").append("<tr>")
            $("#tbody").append("<th>"+y+"</th>")
            for(var x=1;x<11;x++){
                $("#tbody").append('<td id="'+y+x+'"></td>')
            }
            $("#tbody").append("</tr>")
        }

   }