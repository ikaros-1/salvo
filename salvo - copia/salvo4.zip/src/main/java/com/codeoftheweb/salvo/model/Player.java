package com.codeoftheweb.salvo.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.*;

import static java.util.stream.Collectors.toList;

@Entity
public class Player {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
    @GenericGenerator(name = "native", strategy = "native")
    private long id;

    private String userName;

    @OneToMany(mappedBy = "player",fetch = FetchType.EAGER)
    private Set<GamePlayer> gamePlayers;

    @JsonIgnore
    public List<Game> getGames(){
        return gamePlayers.stream().map(gamePlayer -> gamePlayer.getGame()).collect(toList());
    }

    public Player() {
    }

    public Player(String userName) {
        this.userName = userName;
    }

    public Player(String userName,GamePlayer gamePlayer){
        this.gamePlayers=new HashSet<GamePlayer>();
        this.gamePlayers.add(gamePlayer);
        this.userName=userName;
    }

    public void addGamePlayer(GamePlayer gamePlayer){
        this.gamePlayers.add(gamePlayer);
    }

    public String getUserName() {
        return userName;
    }

    public String ToString(){
        return userName;
    }

    public long getId() {
        return id;
    }

    public static Map<String,Object> makePlayerDTO(Player player){
        Map dto = new HashMap<String, Object>();
        dto.put("email", player.getUserName());
        dto.put("id", player.getId());
        return dto;
    }
}