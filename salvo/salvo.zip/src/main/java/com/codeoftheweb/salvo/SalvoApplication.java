package com.codeoftheweb.salvo;

import com.codeoftheweb.salvo.model.Game;
import com.codeoftheweb.salvo.model.GamePlayer;
import com.codeoftheweb.salvo.model.Player;
import com.codeoftheweb.salvo.repository.GamePlayerRepository;
import com.codeoftheweb.salvo.repository.GameRepository;
import com.codeoftheweb.salvo.repository.PlayerRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.temporal.TemporalUnit;

@SpringBootApplication
public class SalvoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalvoApplication.class, args);
	}

	@Bean
	public CommandLineRunner initData(PlayerRepository playerRepository, GameRepository gameRepository, GamePlayerRepository gamePlayerRepository){
		return (args) ->{
		    /*gamePlayerRepository.save(new GamePlayer());
		    repository.save(new Player("Matias"));
			repository.save(new Player("Nahuel"));
			Game game=new Game();
			game.addGamePlayers();
			gameRepository.save(game);
			game=new Game();
			game.setCreationDate(game.getCreationDate().plusHours(1));
            game.addGamePlayers();
			gameRepository.save(game);
            game=new Game();
            game.setCreationDate(game.getCreationDate().plusHours(2));
            game.addGamePlayers();
            gameRepository.save(game);*/
		    /*Player player= new Player("j.bauer@ctu.gov");
		    Player player2= new Player("c.obrian@ctu.gov");
		    repository.save(player);
            repository.save(player2);
		    Game game=new Game();
		    gameRepository.save(game);
            gamePlayerRepository.save(new GamePlayer(game,player));
            gamePlayerRepository.save(new GamePlayer(game,player2));
		    game=new Game();
            game.setCreationDate(game.getCreationDate().plusHours(1));
            gameRepository.save(game);
		    gamePlayerRepository.save(new GamePlayer(game,player));
            gamePlayerRepository.save(new GamePlayer(game,player2));*/

            playerRepository.save(new Player("j.bauer@ctu.gov"));
            playerRepository.save(new Player("c.obrian@ctu.gov"));
            Game game=new Game();
            gameRepository.save(game);
            gamePlayerRepository.save(new GamePlayer(gameRepository.getOne((long)1),playerRepository.getOne((long)1)));
            gamePlayerRepository.save(new GamePlayer(gameRepository.getOne((long)1),playerRepository.getOne((long)2)));
            game=new Game();
            game.setCreationDate(game.getCreationDate().plusHours(1));
            gameRepository.save(game);
            gamePlayerRepository.save(new GamePlayer(gameRepository.getOne((long)2),playerRepository.getOne((long)1)));
            gamePlayerRepository.save(new GamePlayer(gameRepository.getOne((long)2),playerRepository.getOne((long)2)));
            game=new Game();
            game.setCreationDate(game.getCreationDate().plusHours(2));
            gameRepository.save(game);
//			gamePlayerRepository.save(new GamePlayer(gameRepository.getOne((long) 1),repository.getOne((long)1)));
		};
	}

}
