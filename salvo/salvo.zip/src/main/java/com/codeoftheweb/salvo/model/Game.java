package com.codeoftheweb.salvo.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static java.util.stream.Collectors.toList;

@Entity
public class Game<list> {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
    @GenericGenerator(name = "native", strategy = "native")
    private long id;
    private LocalDateTime creationDate;

    @OneToMany(mappedBy = "game",fetch = FetchType.EAGER)
    private Set<GamePlayer> gamePlayers;

    @JsonIgnore
    public List<Player> getPlayers(){
        return gamePlayers.stream().map(gameplayer-> gameplayer.getPlayer()).collect(toList());
    }

    public Game(){this.creationDate= LocalDateTime.now();}

    public Game(GamePlayer gamePlayer){
        this.gamePlayers=new HashSet<GamePlayer>();
        this.gamePlayers.add(gamePlayer);
        this.creationDate= LocalDateTime.now();
    }
    public void addGamePlayers(GamePlayer gamePlayer){
        gamePlayer.setGame(this);
        this.gamePlayers.add(gamePlayer);
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDateTime creationDate) {
        this.creationDate = creationDate;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Set<GamePlayer> getGamePlayers() {
        return gamePlayers;
    }
}
