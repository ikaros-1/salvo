package com.codeoftheweb.salvo.controller;


import com.codeoftheweb.salvo.model.Game;
import com.codeoftheweb.salvo.model.GamePlayer;
import com.codeoftheweb.salvo.model.Player;
import com.codeoftheweb.salvo.repository.GameRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class SalvoController {

    @Autowired
    GameRepository gameRepository;

    @RequestMapping("/games")
    public List<Object> getListGames(){
        List<Game> games = gameRepository.findAll();
        return games.stream().map(this:: makeGamesDTO).collect(Collectors.toList());
    }

    private Map<String,Object> makeGamesDTO(Game game){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        Map map=new HashMap<String,Object>();
        Set<GamePlayer> gamePlayers= game.getGamePlayers();
        map.put("GamePlayers", gamePlayers.stream().map(this::makeGamesPlayerDTO).collect(Collectors.toList()));
        map.put("created",game.getCreationDate().format(formatter));
        map.put("id",game.getId());
        return  map;
    }

    private Map<String,Object> makeGamesPlayerDTO(GamePlayer gamePlayer){
        Map dto = new HashMap<String, Object>();
        dto.put("player", makePlayerDTO(gamePlayer.getPlayer()));
        dto.put("id", gamePlayer.getId());
        return dto;
    }

    private Map<String,Object> makePlayerDTO(Player player){
            Map dto = new HashMap<String, Object>();
            dto.put("email", player.getUserName());
            dto.put("id", player.getId());
            return dto;
    }

}
