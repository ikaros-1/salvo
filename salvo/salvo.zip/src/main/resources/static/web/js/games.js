$(function(){
    loadJson();

})



function loadJson() {
    $.get("/api/games")
    .done(function(games) {
        games.map(function(game){
            if(game.GamePlayers.length <1 )
                $("#Lista").append("<li>"+game.id+" - "+game.created+" ");
            else{
                $("#Lista").append("<li>"+game.id+" - "+game.created+" ");
                game.GamePlayers.map(function(gameplayer){
                    $("#Lista").append(gameplayer.player.email+" ");
                })
                $("#Lista").append("</li>");
            }
        })
    })
    .fail(function( jqXHR, textStatus ) {
      alert("fallo")
    });
  }