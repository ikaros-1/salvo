$.urlParam = function (name) {
    var results = new RegExp('[\?&]' + name + '=([^&#]*)')
        .exec(window.location.search);

    return (results !== null) ? results[1] || 0 : false;
}
var gamesss=[]
const app = new Vue({
    el: "#app",
    data: {
        login: false,
        user: '',
        pass: '',
        table: [],
        games:[],
        mygames:[]
    },
    mounted: function () {
        this.tableScoring();
        this.isLogin();
    },
    methods: {
        logIn: function (event) {
            event.preventDefault();
            $.post("/api/login", { username: this.user, password: this.pass }).done(() => {
                this.login = true;
                alert("Ha iniciado session con exito!!");
                this.tableScoring();

            }).fail((err) => {
                if(err.responseText!="")
                alert(err.responseText);
                else
                alert("error a iniciar sesion");
            })
        },
        signIn: function (event) {
            event.preventDefault();
            /*
            $.post("/api/players",JSON.stringify({userName : this.user, password : this.pass}))
            .done(() =>{
                alert("Gracias por registrarse!!");
                //document.location.href="/web/games.html?this.login=true";
                //document.location.reload();
                this.logIn(event);
            }).fail((err) => {
                alert(err.message);
            })*/
            var that=this;
            $.ajax({
                url: "/api/players",
                contentType: "application/json",
                type: "POST",
                data:JSON.stringify({userName : this.user, password : this.pass}),
                datatype: "json",
                success:function(data) {
                    alert("Gracias por registrarse!!");
                    that.logIn(event)
                },
                error:function(jqXHR, textStatus, errorThrown) {
                    alert(jqXHR.responseText)
                }
              })
                

        },
        logOut: function (event) {
            event.preventDefault();
            $.post("/api/logout").done(() => {
                this.login = false;
                alert("Cerraste sesion con exito!!")
                //document.location.href="/web/games.html?this.login=false";
                this.tableScoring();
                this.games=[];
                this.mygames=[];
            }).fail((err) => {
                if(err.responseText!="")
                alert(err.responseText);
                else
                alert("error al cerrar sesion");
            })
        },
        tableScoring: function () {
            this.table=[{total: 1.5, tied: 1, lost: 0, win: 1, email: "j.bauer@ctu.gov"},
            {total: 0.5, tied: 1, lost: 0, win: 0, email: "c.obrian@ctu.gov"},
            {total: 0, tied: 0, lost: 0, win: 0, email: "hola@adios.com"}]
            //$("#scoring").append("<thead><tr><th>'Name'</th><th>'Total'</th><th>'Won'</th><th>'Lost'</th><th>'Tied'</th></tr></thead>")
            $.get("/api/leaderboard")
                .done( (datos)=> {

                    this.table = datos;
                })
                .fail((error)=> {
                    this.table = "";
                    if(err.responseText!="")
                    alert(err.responseText);
                    else
                    alert("error al cargar tabla");
            })
        },
        isLogin:function(){
            $.get("/api/login")
                .done((json)=>{
                    
                this.login=true;
                this.user=json.username;
                this.GetGames();
                })
                .fail(()=>{
                    this.login=false
                })
        },
        GetGames:function(){
            $.get("/api/games")
                .done((json)=>{
                    this.games=[];
                    this.mygames=[];
                    gamesss=json
                    json=json.games;
                    console.log(json)
                    json.filter(game=>game.players.length<2)
                        .filter((game)=>game.players.findIndex(e=>{console.log(e);return e.username==this.user})==-1)
                       .map((game)=>this.games.push({id:game.id,created:game.created,username:game.players[0].username}));

                    
                    json.filter((game)=>game.players.findIndex(e=>{console.log(e);return e.username==this.user})!=-1)
                        .map((game)=>{
                            game.players=game.players.filter((player)=>player.username!=this.user);
                            if(game.players.length==1)
                            this.mygames.push({id:game.id,created:game.created,oponent:game.players[0].username})
                            else
                            this.mygames.push({id:game.id,created:game.created,oponent:""})
                        })
                        
                })
                .fail((err)=>{
                    if(err.responseText!="")
                    alert(err.responseText);
                    else
                    alert("error al cargar juegos");
                    this.games=[];
                    this.mygames=[];
                })
        },
        join:function(gp){
            $.post("/api/games/"+gp+"/players")
                .done((game)=>window.open('/web/game.html?gp='+game.gpid, '_blank'))
                .fail((err)=>{
                    if(err.responseText!="")
                    alert(err.responseText);
                    else
                    alert("error al unir al juego");
                })
        },
        rejoin:function(gp){
            $.get("/api/games/"+gp+"/player")
                .done((game)=>window.open('/web/game.html?gp='+game.gpid, '_blank'))
                .fail((err)=>{
                    if(err.responseText!="")
                    alert(err.responseText);
                    else
                    alert("error al ir al juego" );
                })
        },
        created:function(){
            $.post("/api/games")
                .done((game)=>{window.open('/web/game.html?gp='+game.gpid, '_blank')})
                .fail((err)=>{
                    if(err.responseText!="")
                    alert(err.responseText);
                    else
                    alert("error al crear el juego");
                
                })
            
        }
    },

})













